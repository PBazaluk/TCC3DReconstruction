# Third Party Tools

- The ATE is borrowed and modified from repo [rpg_trajectory_evaluation](https://github.com/uzh-rpg/rpg_trajectory_evaluation). 
- pytorch_ssim is copied from [pytorch-ssim](https://github.com/Po-Hsun-Su/pytorch-ssim).