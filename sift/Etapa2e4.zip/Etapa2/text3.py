import numpy as np
import cv2 as cv
import glob
import os
import matplotlib.pyplot as plt

print("zzz")

# Diretórios das imagens e de saída
image_dir = 'C:/Users/aless/OneDrive/Documentos/sift/Etapa2/imgs/'
image_out = 'C:/Users/aless/OneDrive/Documentos/sift/Etapa2/imgswd/'

# Listar todos os arquivos de imagem no diretório
image_files = glob.glob(os.path.join(image_dir, '*.jpg'))

print("image files:", image_files)

# Inicializar dicionários e lista
vector = {}
imgs_des = {}
imgs_kp = {}
lista = []
lista_images =[]

# Processar cada imagem
for file in image_files:
    img = cv.imread(file)
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    
    # Criar o detector SIFT
    sift = cv.SIFT_create()
    
    # Detectar keypoints e calcular descritores
    kp, des = sift.detectAndCompute(gray, None)
    
    # Ordenar keypoints com base na resposta e selecionar os melhores
    keypoints = sorted(kp, key=lambda x: x.response, reverse=True)
    num_best_keypoints = 4000
    keypoints = keypoints[:num_best_keypoints]
    lista_images.append(gray)
    # Desenhar os keypoints na imagem
    img_with_keypoints = cv.drawKeypoints(gray, keypoints, img, flags=cv.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    output_file = os.path.splitext(file)[0] + '_keypoints.jpg'
    novo_path = output_file.replace("imgs", "imgswd")
    cv.imwrite(novo_path, img_with_keypoints)
    lista.append(novo_path)
    imgs_des[novo_path] = des
    imgs_kp[novo_path] = keypoints

print(imgs_des[lista[0]])
print("==============================================================")
print(imgs_des[lista[1]])
print("==============================================================")
print(imgs_kp[lista[0]])
print("==============================================================")
print(imgs_kp[lista[1]])
print("==============================================================")
print(lista_images[0])
print(lista_images[1])
# bf = cv.BFMatcher()
# matches = bf.knnMatch(imgs_des[lista[0]],imgs_des[lista[1]],k=2)
# # Apply ratio test
# good = []
# for m,n in matches:
#     if m.distance < 0.75*n.distance:
#         good.append([m])
# # cv.drawMatchesKnn expects list of lists as matches.
# img3 = cv.drawMatchesKnn(lista_images[0],imgs_kp[lista[0]],lista_images[1],imgs_kp[lista[1]],good,None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
# plt.imshow(img3),plt.show()


# # print(imgs_des[lista[0]].dtype, imgs_des[lista[1]].dtype)
# # # create BFMatcher object

# # # create BFMatcher object
# # bf = cv.BFMatcher(cv.NORM_HAMMING, crossCheck=True)
# # Match descriptors.
# matches = bf.knnMatch(imgs_des[lista[0]],imgs_des[lista[1]],k=2)

# # Sort them in the order of their distance.
# matches = sorted(matches, key = lambda x:x.distance)
# # Draw first 10 matches.
# img3 = cv.drawMatchesKnn(lista_images[0],imgs_kp[lista[0]],lista_images[1],imgs_kp[lista[1]],matches[:10],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
# plt.imshow(img3),plt.show()


# FLANN parameters
FLANN_INDEX_KDTREE = 1
index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
search_params = dict(checks=50)   # or pass empty dictionary
flann = cv.FlannBasedMatcher(index_params,search_params)
matches = flann.knnMatch(imgs_des[lista[0]],imgs_des[lista[1]],k=2)
# Need to draw only good matches, so create a mask
matchesMask = [[0,0] for i in range(len(matches))]
# ratio test as per Lowe's paper
for i,(m,n) in enumerate(matches):
    if m.distance < 0.7*n.distance:
        matchesMask[i]=[1,0]
draw_params = dict(matchColor = (0,255,0),
                   singlePointColor = (255,0,0),
                   matchesMask = matchesMask,
                   flags = cv.DrawMatchesFlags_DEFAULT)

img3 = cv.drawMatchesKnn(lista_images[0],imgs_kp[lista[0]],lista_images[1],imgs_kp[lista[1]],matches,None,**draw_params)
plt.imshow(img3,),plt.show()